package via_cep.service;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import javax.net.ssl.HttpsURLConnection;

import via_cep.Exception.ViaCEPException;

public class viaCEPClient {
	
	private static final String BASE_URL = "https://viacep.com.br/ws/";
	
	public static String getAddressInfo(String address) throws ViaCEPException, IOException{
		
		// criar a URL para a consulta do CEP
		// Precisa ter um try catch
		
		try {
			URL url = new URL(BASE_URL + address + "/json");
			
			// abrir a conexão HTTP
			HttpURLConnection con = (HttpsURLConnection) url.openConnection();
			
			con.setRequestMethod("GET");
			
			// Verifica se a requisição foi bem sucedida.
			if(con.getResponseCode() == 200) {
				// Se deu certo, vamos ler os dados da resposta
				BufferedReader reader = new BufferedReader(new InputStreamReader(con.getInputStream()));
				StringBuilder response = new StringBuilder();
				String line;
				
				while((line = reader.readLine()) != null) {
					response.append(line);
				}
				
				if(response.toString().contains("\"erro\":true")) {
					throw new ViaCEPException("CEP not found" + address + "." + "Try again");
				}
				
				// fechar a conexão
				reader.close();
				con.disconnect();
				
				return response.toString();
			}else {
				// Caso a requisição tenha falhando, lance uma exceção com o código de erro.
				throw new ViaCEPException("Failed to connect. Erros code: " + con.getResponseCode());
			}
		}catch (IOException e) {
			throw new ViaCEPException("Error while accessing viaCEP API: " + e.getMessage(), e);
		}
		
	}
	
}
